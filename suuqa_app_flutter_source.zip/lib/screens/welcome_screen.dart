import 'package:flutter/material.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Spacer(),
              const Icon(Icons.storefront_rounded, size: 72, color: Color(0xFF0F766E)),
              const SizedBox(height: 16),
              const Text(
                'Ku Soo Dhawoow Suuqa',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              const Text(
                'Dooro qaybta aad doonayso inaad gasho:',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 14, color: Colors.grey),
              ),
              const Spacer(),
              ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF0F766E),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                icon: const Icon(Icons.shopping_cart_outlined),
                label: const Text('Waxaan ahay Macmiil (I am a Customer)', style: TextStyle(fontSize: 15)),
                onPressed: () => Navigator.pushNamed(context, '/customer_home'),
              ),
              const SizedBox(height: 12),
              OutlinedButton.icon(
                style: OutlinedButton.styleFrom(
                  foregroundColor: const Color(0xFF0F766E),
                  side: const BorderSide(color: Color(0xFF0F766E), width: 1.5),
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                icon: const Icon(Icons.store_outlined),
                label: const Text('Waxaan ahay Ganacsade (Store Login)', style: TextStyle(fontSize: 15)),
                onPressed: () => Navigator.pushNamed(context, '/store_login'),
              ),
              const SizedBox(height: 12),
              TextButton.icon(
                icon: const Icon(Icons.admin_panel_settings_outlined, size: 18),
                label: const Text('Maamulka Sare (Super Admin)'),
                onPressed: () => Navigator.pushNamed(context, '/super_admin'),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}
