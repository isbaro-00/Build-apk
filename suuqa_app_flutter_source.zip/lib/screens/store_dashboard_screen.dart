import 'package:flutter/material.dart';

class StoreDashboardScreen extends StatelessWidget {
  const StoreDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Hodan Boutique - Dashboard'),
        backgroundColor: const Color(0xFF0F766E),
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () => Navigator.pushReplacementNamed(context, '/welcome'),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                _buildStatCard('Dakhliga Guud', '$4,850', Icons.attach_money, Colors.emerald),
                const SizedBox(width: 12),
                _buildStatCard('Dalabaadka', '142', Icons.shopping_cart, Colors.blue),
              ],
            ),
            const SizedBox(height: 24),
            const Text('Alaabta Dukaanka (Products)', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            ListTile(
              tileColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
              leading: const Icon(Icons.checkroom, color: Color(0xFF0F766E)),
              title: const Text('Dirac Aroos Qaali ah'),
              subtitle: const Text('Kaydka: 14 xabo | $125'),
              trailing: const Chip(label: Text('Firfircoon', style: TextStyle(fontSize: 11, color: Colors.green))),
            ),
            const SizedBox(height: 8),
            ListTile(
              tileColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
              leading: const Icon(Icons.checkroom, color: Color(0xFF0F766E)),
              title: const Text('Dirac Shiifon Bacweyne'),
              subtitle: const Text('Kaydka: 28 xabo | $35'),
              trailing: const Chip(label: Text('Firfircoon', style: TextStyle(fontSize: 11, color: Colors.green))),
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Form-ka ku darista alaab cusub.')),
                );
              },
              icon: const Icon(Icons.add),
              label: const Text('Ku Dar Alaab Cusub'),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF0F766E),
                foregroundColor: Colors.white,
                minimumSize: const Size.fromHeight(48),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatCard(String title, String val, IconData icon, MaterialColor col) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.grey.shade200),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: const Color(0xFF0F766E)),
            const SizedBox(height: 8),
            Text(title, style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
            const SizedBox(height: 4),
            Text(val, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
          ],
        ),
      ),
    );
  }
}
