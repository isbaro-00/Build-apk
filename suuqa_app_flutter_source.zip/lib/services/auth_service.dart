import 'package:shared_preferences/shared_preferences.dart';

class AuthService {
  static const String keyRole = 'user_role';
  static const String keyStoreId = 'logged_store_id';
  static const String keyIsLoggedIn = 'is_logged_in';

  // Kaydi doorka qofka (Customer, Store, Admin)
  static Future<void> saveUserRole(String role) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(keyRole, role);
    await prefs.setBool(keyIsLoggedIn, true);
  }

  // Hel doorka hadda kaydsan
  static Future<String?> getUserRole() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(keyRole);
  }

  // Gelitaanka Dukaanka
  static Future<bool> loginStore(String phone, String password) async {
    final prefs = await SharedPreferences.getInstance();
    // Demo verification
    if (password == '123456') {
      await prefs.setString(keyRole, 'store_owner');
      await prefs.setString(keyStoreId, phone);
      await prefs.setBool(keyIsLoggedIn, true);
      return true;
    }
    return false;
  }

  // Ka bixidda (Sign out)
  static Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
  }
}
