import 'package:flutter/material.dart';
import 'screens/splash_screen.dart';
import 'screens/welcome_screen.dart';
import 'screens/customer_home_screen.dart';
import 'screens/store_login_screen.dart';
import 'screens/store_dashboard_screen.dart';
import 'screens/super_admin_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const SuuqaApp());
}

class SuuqaApp extends StatelessWidget {
  const SuuqaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Suuqa App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF0F766E), // Emerald Green
          primary: const Color(0xFF0F766E),
          secondary: const Color(0xFF0284C7), // Blue
        ),
        scaffoldBackgroundColor: const Color(0xFFF8FAFC),
        fontFamily: 'Roboto',
        useMaterial3: true,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => const SplashScreen(),
        '/welcome': (context) => const WelcomeScreen(),
        '/customer_home': (context) => const CustomerHomeScreen(),
        '/store_login': (context) => const StoreLoginScreen(),
        '/store_dashboard': (context) => const StoreDashboardScreen(),
        '/super_admin': (context) => const SuperAdminScreen(),
      },
    );
  }
}
