# Suuqa App - Flutter Source Code

Mashruuca Suuqa App ee lagu dhisay Flutter (Dukaan Weyn, Dukaan Yar, In-App Chat, Super Admin).

## Sida loo kiciyo:
1. Ku qor Terminal-ka: `flutter pub get`
2. Ku dhis APK-ga: `flutter build apk --release`
3. Faylka APK wuxuu diyaar ku yahay: `build/app/outputs/flutter-apk/app-release.apk`

Waxaa ku jira dhammaan shaashadaha cusub:
- Splash Screen (Furitaanka)
- Welcome Screen (Doorashada Macmiil / Ganacsade / Maamule)
- Customer Home Screen (Suuqa Macmiilka, EVC/Zaad & Follow Dukaanka)
- Store Login & Register (Dukaan Weyn oo shaqaale leh vs Dukaan Yar)
- Store Dashboard (Sawirka alaabta, shaqaalaha, beddelka password-ka)
- Super Admin Screen (Abuurista dukaan, edit, aqbalaad maalmo leh & preview)
- In-App Live Chat (Beddelay WhatsApp)
